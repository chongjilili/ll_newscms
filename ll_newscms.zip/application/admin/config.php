<?php
/**
 * Created by PhpStorm.
 * User: lili
 * Date: 2018/1/7
 * Time: 14:29
 */


return [
    // 视图输出字符串内容替换
    'view_replace_str'       => [
        '__PUBLIC__' => __ROOT__.'public',
        '__STATIC__' => __ROOT__.'public/static',
        '__P__' => __ROOT__.'public/admin',
        '__U__' => __ROOT__.'public/uploads',
    ],

];