<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"D:\program\phpStudy\WWW\ll_newscms./application/index\view\index_login.html";i:1515306052;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>登陆模块</title>
</head>
<body>

</body>
</html>